
public class Help {

	public static void main(String[] args) {
		System.out.println(" _   _  _____  _      _____");
		System.out.println("| | | ||  ___|| |    | ___ \\");
		System.out.println("| |_| || |__  | |    | |_/ /");
		System.out.println("|  _  ||  __| | |    |  __/");
		System.out.println("| | | || |___ | |____| |");
		System.out.println("\\_| |_/\\____/ \\_____/\\_|");
	}
}